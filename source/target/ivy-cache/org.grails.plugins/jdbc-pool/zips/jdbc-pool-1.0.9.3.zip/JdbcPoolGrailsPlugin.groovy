class JdbcPoolGrailsPlugin {
    // the plugin version
    def version = "1.0.9.3"
    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "1.3.1 > *"
    // the other plugins this plugin depends on
    def dependsOn = [:]
    def loadAfter = ['dataSource','datasources']
    // resources that are excluded from plugin packaging
    def pluginExcludes = [
            "grails-app/views/error.gsp"
    ]

    def author = "Lari"
    def authorEmail = "lari.hotari@sagire.fi"
    def title = "Tomcat JDBC Pool plugin"
    def description = '''\\
Replaces default Grails Commons DBCP Pool with Tomcat JDBC Pool (http://people.apache.org/~fhanik/jdbc-pool/).
Compatible with built-in dataSource plugin and the datasources plugin.
'''

    // URL to the plugin's documentation
    def documentation = "http://grails.org/JdbcPool+Plugin"

    def doWithSpring = {
	springConfig.beanNames.each { beanName ->
		def beanconf=springConfig.getBeanConfig(beanName)
		def beandef=(beanconf) ? beanconf.beanDefinition : springConfig.getBeanDefinition(beanName)
		if(beandef && beandef.beanClassName=='org.apache.commons.dbcp.BasicDataSource') {
			beandef.beanClassName='org.apache.tomcat.jdbc.pool.DataSource'
		}
	}
    }

}
